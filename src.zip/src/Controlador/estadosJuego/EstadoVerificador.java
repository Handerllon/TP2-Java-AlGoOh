package Controlador.estadosJuego;

public interface EstadoVerificador
{
    boolean esFallido();

    String getNombre();
}
