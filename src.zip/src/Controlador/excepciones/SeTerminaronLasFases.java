package Controlador.excepciones;

public class SeTerminaronLasFases extends RuntimeException
{
}
