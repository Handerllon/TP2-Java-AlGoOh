package Controlador.observadores;

public interface ObservadorDeControlador
{
    void seTerminoElTurno();

    void seTerminoLaFase();
}
