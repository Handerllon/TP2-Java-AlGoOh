package Modelo.carta.excepciones;

public class CartaInvalidaError extends RuntimeException
{
}
