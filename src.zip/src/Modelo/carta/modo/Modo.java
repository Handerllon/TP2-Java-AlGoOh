package Modelo.carta.modo;

import Modelo.carta.monstruo.CartaMonstruo;

public interface Modo
{
    void cambiarModo(CartaMonstruo carta);

    boolean esAtaque();

    boolean esDefensa();
}
