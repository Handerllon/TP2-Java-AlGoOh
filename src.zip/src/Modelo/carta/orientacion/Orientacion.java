package Modelo.carta.orientacion;

public interface Orientacion
{
    void cambiarOrientacion();

    boolean estaBocaArriba();

    boolean estaBocaAbajo();
}
