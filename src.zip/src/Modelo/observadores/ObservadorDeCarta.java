package Modelo.observadores;

public interface ObservadorDeCarta
{
    void cartaCambioDeOrientacion();
}
