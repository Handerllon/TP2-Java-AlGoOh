package Modelo.observadores;

public interface ObservadorDeCartaMonstruo
{
    void cartaCambioDeModo();
}
