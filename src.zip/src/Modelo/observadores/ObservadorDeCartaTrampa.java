package Modelo.observadores;

import Modelo.carta.trampa.CartaTrampa;

public interface ObservadorDeCartaTrampa
{
    void seUsoCartaTrampa(CartaTrampa cartaTrampa);
}
