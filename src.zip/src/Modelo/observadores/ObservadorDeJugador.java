package Modelo.observadores;

public interface ObservadorDeJugador
{
    void cambiaronLosPuntosDeVida();
}
