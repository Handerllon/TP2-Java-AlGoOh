package Modelo.observadores;

public interface ObservadorDeMano
{
    void ingresoCartaAMano();

    void egresoCartaAMano();
}
