package Modelo.observadores;

public interface ObservadorDeMazo
{
    void seTomoCartaDeMazo();
}
